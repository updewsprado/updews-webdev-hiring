package com.updews.actions;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.updews.beans.UserBean;

public class SubscribeAction extends ActionSupport{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String fullName;
	private String email;
	private String age;
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	
	@Override
	public String execute() throws Exception {
		UserBean user = new UserBean();
		user.setFullName(fullName);
		user.setEmail(email);
		user.setAge(age);
		Map<String , Object> session = ActionContext.getContext().getSession();
		session.put("userObj", user);
		return SUCCESS;
	}
	

}
